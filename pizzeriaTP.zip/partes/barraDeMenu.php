<div id="header">
		
			<a class="btn btn-primary animated bounceInLeft" href="index.php"><span class="glyphicon glyphicon-list-alt">&nbsp;</span>Menu principal</a>
			<a class="btn btn-primary animated bounceInLeft" href="formGrilla.php"> <span class="glyphicon glyphicon-th">&nbsp;</span>   Grilla</a>
			<a class="btn btn-primary animated bounceInLeft" href="formGrillaWS.php"><span class="glyphicon glyphicon-th">&nbsp;</span>Grilla WS</a>
			<a class="btn btn-primary animated bounceInLeft" href="formAlta.php"><span class="glyphicon glyphicon-plus-sign">&nbsp;</span>Alta</a>
		

			<span id="tituloBarra"  class="animated bounceInRight">ABM -  Versión 1.0.5 -Store Procedure</span>

	</div>